﻿namespace SecondCliburnApp.Models
{
    public class PersonModel
    {
        public string LastName { get; set; }
        public string FirstName { get; set; }
    }
}
