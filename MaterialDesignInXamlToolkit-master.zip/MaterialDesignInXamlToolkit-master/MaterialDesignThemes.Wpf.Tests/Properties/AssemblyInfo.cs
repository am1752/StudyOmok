﻿using System.Reflection;
using System.Runtime.InteropServices;
using Xunit;

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("a361c80e-f6cd-4c57-a96c-002db159c1f4")]

[assembly: CollectionBehavior(DisableTestParallelization = true)]