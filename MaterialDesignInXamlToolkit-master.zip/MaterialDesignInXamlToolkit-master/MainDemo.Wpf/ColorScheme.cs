﻿namespace MaterialDesignDemo
{
    enum ColorScheme
    {
        Primary,
        Secondary,
        PrimaryForeground,
        SecondaryForeground
    }
}
