﻿using System.Windows.Controls;

namespace MaterialDesignColors.WpfExample.Domain
{
    /// <summary>
    /// Interaction logic for SampleProgressDialog.xaml
    /// </summary>
    public partial class SampleProgressDialog : UserControl
    {
        public SampleProgressDialog()
        {
            InitializeComponent();
        }
    }
}
