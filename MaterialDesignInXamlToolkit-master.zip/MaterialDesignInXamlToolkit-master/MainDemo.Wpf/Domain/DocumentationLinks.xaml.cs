﻿using System.Windows.Controls;

namespace MaterialDesignDemo.Domain
{
    /// <summary>
    /// Interaction logic for DocumentationLinks.xaml
    /// </summary>
    public partial class DocumentationLinks : UserControl
    {
        public DocumentationLinks()
        {
            InitializeComponent();
        }
    }
}
