﻿namespace MaterialDesignThemes.Wpf
{
    public enum ComboBoxPopupPlacement
    {
        Undefined,
        Down,
        Up,
        Classic
    }
}