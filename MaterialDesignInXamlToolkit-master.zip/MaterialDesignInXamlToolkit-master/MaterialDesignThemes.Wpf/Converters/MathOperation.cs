﻿namespace MaterialDesignThemes.Wpf.Converters
{
    public enum MathOperation
    {
        Add,
        Subtract,
        Multiply,
        Divide,
        Pow
    }
}
